# WALLOP — Steam Trailer Brief

Thanks for making our launch trailer! Everything you need is in this folder.
Questions welcome anytime.

---

## The game in one line
**WALLOP** is a 3D bullet-heaven roguelike: you're a pizza-delivery hero
walloping through swarms of food-themed monsters. You **move and dodge**, the
**weapons auto-fire**, and you **pick upgrades** on level-up to snowball into an
absurd, screen-clearing build — then take down giant boss chefs.

Think *Vampire Survivors / Megabonk*, but 3D and pizza-themed. **Tone:** fast,
chunky, punchy, fun. Tagline: **"smash. survive. snowball."**

Steam page (for reference + the wishlist call-to-action):
https://store.steampowered.com/app/4910280/WALLOP/

---

## Deliverable
- **Main trailer: 60–75 seconds**, 1920×1080, **H.264 MP4**, 30 or 60 fps, stereo audio.
- Hook in the **first 5 seconds** — most viewers bail by 30s, so front-load the best carnage.
- **The very first frame is the thumbnail** on the Steam page before anyone hits play — make it a strong ACTION frame, never a black/logo frame.
- Nice-to-have if easy: a **6-second vertical/short cut** for social (TikTok/Reels).

---

## Recording setup
- Please record the **desktop build we sent** (best visuals — it has bloom + color grading). OBS game-capture the window at **1080p, 60fps, high bitrate (~20–40 Mbps)**.
- **Unlock everything first** so you can film all content — see `1_UNLOCK_EVERYTHING.txt`.
- **F9 hides the HUD** for clean cinematic shots; **F11** toggles fullscreen.
- Difficulty/arena/character are all chosen on the start screen (all unlocked).

---

## Shot list / structure (~70s)
1. **Hook (0–5s):** straight into chaos — a dense swarm getting deleted, or a boss telegraph → screen-clear. Quick WALLOP logo sting over the action, then keep moving.
2. **Core loop (5–25s):** show auto-combat + dodging; cut to a **level-up choice screen** picking a weapon; show that new weapon firing. Message: *"you move + pick, the weapons do the rest."*
3. **Snowball (25–45s):** the build coming online — multiple weapons + orbiting pizzas + chain lightning, bigger swarms melting. Escalating pace, cut on the hits.
4. **Variety (45–60s):** quick cuts — the **3 arenas** (green forest, autumn slopes, snow glacier), a **mini-boss and the final Warlord**, a couple of distinct **characters/weapons**. Proves depth.
5. **Meta (60–68s):** flash the **Armory** (unlocks) + character select + a challenge. *"Progress carries over."*
6. **Close (68–72s):** logo + **"smash. survive. snowball."** + **"Wishlist now on Steam"** card. End on the logo.

## Must-show features
- Auto-firing weapons + player movement/dodging
- Level-up upgrade picks (the choice cards)
- A snowballed build melting a big swarm
- All 3 arenas · at least one boss fight (ideally the Warlord)
- A couple of different characters/weapons · the Armory screen

## Editing notes
- Cut on the beat; match cuts to explosions/hits. Keep clips ~1.5–3s — momentum > lingering.
- **Text callouts: 2–4 max**, e.g. `AUTO-FIGHT` · `STACK ABSURD BUILDS` · `3 ARENAS · 3 BOSSES`. Use our fonts (see brand kit).
- Feel free to grade a touch punchier.

---

## Brand kit (in the `brand/` folder we sent)
- **Logo:** transparent WALLOP wordmark (`library-logo.png`) — for the sting + end card.
- **Fonts:** `Press Start 2P` (headings/callouts) + `VT323` (body). Please use these for any on-screen text.
- **Colors:** navy `#0d1126`, yellow `#ffd23f`, red/pink `#ff3864`.
- **Reference art:** the Steam capsules/screenshots for style consistency.

---

## Music — please read
- **Use royalty-free / CC0 or licensed-for-commercial music only.** Steam issues copyright strikes and can pull the trailer. Do **not** use popular/copyrighted tracks.
- Vibe: **punchy chiptune / synthwave / upbeat electronic** that matches the retro pixel style. If you have a go-to royalty-free track that fits, great — send us the name so we can confirm the license.
